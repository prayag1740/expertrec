from setuptools import find_packages, setup

setup(
    name = 'myplexerlib',
    packages = find_packages(include=['myplexer_lib']),
    version = '0.2.0',
    description = 'My first python library',
    author = 'Prayag',
    license = 'MIT'
)